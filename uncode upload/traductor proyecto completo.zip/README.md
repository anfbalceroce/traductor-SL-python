# Traductor de lenguaje SL a Python 3
Proyecto para el curso **Lenguajes de programacion** **2022-1** de la Universidad Nacional de Colombia.

Se utilizo ANTLR v4 y una gramatica propia desarrollada durante el curso, inicialmente LL(1) y luego fue modificada gracias a las capacidades de ANTLR.

Se utilzaron las estructuras de Listener de ANTLR para la traduccion.

Salida por consola y en archivo out.p

Integrantes del grupo de trabajo:
* **Sergio Camilo Espinosa Botero** - sespinosab@unal.edu.co
* **Juan Sebastian Reina Zamora** - jreinaz@unal.edu.co
* **Andrés Felipe Balcero Cerón** - anfbalceroce@unal.edu.co
* **Hamed Mohseni** - hamohseni@unal.edu.co
