a = b = cociente = 0

print("\nPrograma para calcular cociente de la division", "entera de dos numeros, ambos enteros.")
print("\nIngrese dos numeros enteros, separados por comas:")
a = 111
b = 7
cociente = 0
while a >= b:
	a = a - b
	cociente = cociente + 1
print("\nEl cociente es ", a);
