// Generated from C:/Users/Platez/Documents/UN/Sistemas/2022-1/lenguajes/traductor/grammar\SL.g4 by ANTLR 4.10.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SLParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SLVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SLParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(SLParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#header}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeader(SLParser.HeaderContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#var}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar(SLParser.VarContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#const}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConst(SLParser.ConstContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#tipo_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo_p(SLParser.Tipo_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#main}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain(SLParser.MainContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#sentencia}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSentencia(SLParser.SentenciaContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCall(SLParser.CallContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#assingment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssingment(SLParser.AssingmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#if}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf(SLParser.IfContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#sinosi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSinosi(SLParser.SinosiContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#while}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhile(SLParser.WhileContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#do_while}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_while(SLParser.Do_whileContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#switch}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwitch(SLParser.SwitchContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#case}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCase(SLParser.CaseContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#sino}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSino(SLParser.SinoContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#for}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFor(SLParser.ForContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#m_expresion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitM_expresion(SLParser.M_expresionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#m_expresion_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitM_expresion_p(SLParser.M_expresion_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#m_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitM_term(SLParser.M_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#m_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitM_factor(SLParser.M_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#expresion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpresion(SLParser.ExpresionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#logic_expresion_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogic_expresion_p(SLParser.Logic_expresion_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#logic_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogic_term(SLParser.Logic_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#logic_term_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogic_term_p(SLParser.Logic_term_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#logic_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogic_factor(SLParser.Logic_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#logic_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogic_element(SLParser.Logic_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#bool}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBool(SLParser.BoolContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#relation_expresion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelation_expresion(SLParser.Relation_expresionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#relation_expresion_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelation_expresion_p(SLParser.Relation_expresion_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#relation_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRelation_term(SLParser.Relation_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_expresion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_expresion(SLParser.Num_expresionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_expresion_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_expresion_p(SLParser.Num_expresion_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_term}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_term(SLParser.Num_termContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_term_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_term_p(SLParser.Num_term_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_factor(SLParser.Num_factorContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_factor_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_factor_p(SLParser.Num_factor_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#num_factor_pp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNum_factor_pp(SLParser.Num_factor_ppContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#base_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBase_element(SLParser.Base_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#sub}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSub(SLParser.SubContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#args}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs(SLParser.ArgsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#ref}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRef(SLParser.RefContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#submain}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubmain(SLParser.SubmainContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#submainr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSubmainr(SLParser.SubmainrContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#calls}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCalls(SLParser.CallsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#tipo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipo(SLParser.TipoContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#tipos}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTipos(SLParser.TiposContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#type_vector}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_vector(SLParser.Type_vectorContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#v_len}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitV_len(SLParser.V_lenContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#type_matrix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType_matrix(SLParser.Type_matrixContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#dimention_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDimention_list(SLParser.Dimention_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#next_dimention}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNext_dimention(SLParser.Next_dimentionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#next_dimention_p}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNext_dimention_p(SLParser.Next_dimention_pContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#dimention}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDimention(SLParser.DimentionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#register}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegister(SLParser.RegisterContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#id_extend}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitId_extend(SLParser.Id_extendContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#ids_options}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIds_options(SLParser.Ids_optionsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#params}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParams(SLParser.ParamsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#next_param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNext_param(SLParser.Next_paramContext ctx);
	/**
	 * Visit a parse tree produced by {@link SLParser#matrix}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMatrix(SLParser.MatrixContext ctx);
}