k = 0

for k in range( 10 ,  1 ,  -  1 ):
	print( "\n"  ,  k  ,  " :\t"  ,  k ** 2 )
