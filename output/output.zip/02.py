total = 0
num = 0

total =  0 
num =  1000 
while  num  <=  9999 :
	total =  total  +  num 
	num =  num  +  1 
print("\nSerá recaudada la suma de Gs. ",total);